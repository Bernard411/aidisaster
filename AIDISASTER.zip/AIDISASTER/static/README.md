## Title- Disaster Management and Climate Change Stopping, Monitoring, Awareness through an AI-Enabled Mobile Application and Website Platform.




![alt text](http://url/to/img.png)
![alt text](http://url/to/img.png)
![alt text](http://url/to/img.png)
![alt text](http://url/to/img.png)
![alt text](http://url/to/img.png)