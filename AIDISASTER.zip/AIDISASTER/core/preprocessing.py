import torch

def preprocess_temperature_data(input_data):
    # Assuming 'values' is a key in input_data containing the temperature values
    temperature_values = input_data.get('values', [])

    # Implement additional preprocessing logic if needed
    # Example: Scaling or normalizing the temperature values
    # temperature_values = some_preprocessing_function(temperature_values)

    # Convert to a PyTorch tensor
    temperature_data = torch.tensor(temperature_values, dtype=torch.float32)
    return temperature_data

def preprocess_rainfall_data(input_data):
    # Assuming 'values' is a key in input_data containing the rainfall values
    rainfall_values = input_data.get('values', [])

    # Implement additional preprocessing logic if needed
    # Example: Scaling or normalizing the rainfall values
    # rainfall_values = some_preprocessing_function(rainfall_values)

    # Convert to a PyTorch tensor
    rainfall_data = torch.tensor(rainfall_values, dtype=torch.float32)
    return rainfall_data
