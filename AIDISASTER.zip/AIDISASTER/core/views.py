from .models import District, RainfallData
from .forms import AllDataForm
from django.shortcuts import render, redirect
from django.urls import reverse
from django.http import HttpResponseRedirect
from django.contrib.auth import authenticate, login
from django.shortcuts import render
from . import models
from django.shortcuts import render, get_object_or_404
from .models import District, TemperatureData, RainfallData, DisasterHistory
from django.shortcuts import render
from django.http import JsonResponse
import torch


from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from .preprocessing import preprocess_temperature_data, preprocess_rainfall_data
# Create your views here.


def home(request):
    districts = models.District.objects.all()
    context = {
        'districts': districts
    }
    return render(request, 'index.html', context)


def landing(request, district_id):
    districts = models.District.objects.all()
    district = get_object_or_404(District, pk=district_id)
    temperature_data = TemperatureData.objects.filter(district=district)
    rainfall_data = RainfallData.objects.filter(district=district)
    disaster_history = DisasterHistory.objects.filter(district=district)

    return render(request, 'home.html', {
        'district': district,
        'districts': districts,
        'temperature_data': temperature_data,
        'rainfall_data': rainfall_data,
        'disaster_history': disaster_history,
    })


def disaster_prediction(request):
    # Get input data from the request, assuming it's a POST request with JSON data
    input_data = request.POST.get('input_data', '{}')
    input_data = json.loads(input_data)

    # Preprocess input data for temperature and rainfall models
    temperature_data = preprocess_temperature_data(
        input_data.get('temperature', {}))
    rainfall_data = preprocess_rainfall_data(input_data.get('rainfall', {}))

    # Load and use the trained temperature model
    temperature_model = TemperatureModel()
    temperature_model.load_state_dict(
        torch.load('path/to/temperature_model.pth'))
    temperature_model.eval()

    with torch.no_grad():
        temperature_prediction = temperature_model(temperature_data)

    # Load and use the trained rainfall model
    rainfall_model = RainfallModel()
    rainfall_model.load_state_dict(torch.load('path/to/rainfall_model.pth'))
    rainfall_model.eval()

    with torch.no_grad():
        rainfall_prediction = rainfall_model(rainfall_data)

    # Format the predictions as needed
    predictions = {
        'temperature_prediction': temperature_prediction.item(),
        'rainfall_prediction': rainfall_prediction.item(),
    }

    # Return the predictions as JSON
    return JsonResponse(predictions)


# myapp/views.py


def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            # Redirect to a success page
            return HttpResponseRedirect(reverse('home-page'))
        else:
            # Return an invalid login message or handle as needed
            return render(request, 'login.html', {'error_message': 'Invalid login credentials'})

    return render(request, 'login.html')


def logoutuser(request):
    logout(request)
    return redirect('home-page')


# views.py


def add_all_data(request):

    district = models.District.objects.all()

    if request.method == 'POST':
        form = AllDataForm(request.POST)
        if form.is_valid():
            # Save District data
            district = form.save(commit=False)
            district.save()

            # Save related TemperatureData
            TemperatureData.objects.create(
                district=district,
                month=form.cleaned_data['temperature_month'],
                year=form.cleaned_data['temperature_year'],
                average_temperature=form.cleaned_data['temperature_average_temperature']
            )

            # Save related RainfallData
            RainfallData.objects.create(
                district=district,
                month=form.cleaned_data['rainfall_month'],
                year=form.cleaned_data['rainfall_year'],
                rainfall_amount=form.cleaned_data['rainfall_rainfall_amount']
            )

            # Save related PopulationDensity
            models.PopulationDensity.objects.create(
                district=district,
                year=form.cleaned_data['population_density_year'],
                population_density=form.cleaned_data['population_density_population_density']
            )

            # Save related VegetationHealth
            models.VegetationHealth.objects.create(
                district=district,
                month=form.cleaned_data['vegetation_health_month'],
                year=form.cleaned_data['vegetation_health_year'],
                ndvi_value=form.cleaned_data['vegetation_health_ndvi_value']
            )

            # Save related DisasterType
            disaster_type, _ = models.DisasterType.objects.get_or_create(
                district=district,
                name=form.cleaned_data['disaster_type_name']
            )

            # Save related DisasterHistory
            DisasterHistory.objects.create(
                district=district,
                disaster_type=disaster_type,
                severity_level=form.cleaned_data['disaster_history_severity_level'],
                occurrence_date=form.cleaned_data['disaster_history_occurrence_date']
            )

            # Replace 'success_url' with the actual URL you want to redirect to upon successful form submission
            return redirect('success_url')
    else:
        form = AllDataForm()

    return render(request, 'data.html', {'form': form, 'district': district})

# views.py
# views.py


def data(request):
    district = models.District.objects.all()
    context = {
        'district': district

    }

    return render(request, 'data.html', context)


# views.py

from django.shortcuts import render
from .models import District

def update_view(request):
    districts = District.objects.all()

    # Fetch disaster data for each district and disaster type
    district_data = {}
    for district in districts:
        district_data[district.name] = {
            "Flood": district.disasterhistory_set.filter(disaster_type__name='Flood').count(),
            "Drought": district.disasterhistory_set.filter(disaster_type__name='Drought').count(),
            "Wildfire": district.disasterhistory_set.filter(disaster_type__name='Wildfire').count(),
            # Add data for other disaster types...
        }

    return render(request, 'home.html', {'districts': districts, 'district_data': district_data})

