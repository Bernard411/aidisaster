# forms.py

from django import forms
from .models import (
    District,
    TemperatureData,
    RainfallData,
    PopulationDensity,
    VegetationHealth,
    DisasterType,
    DisasterHistory,
)


class AllDataForm(forms.ModelForm):
    class Meta:
        model = District
        fields = '__all__'
       

    temperature_month = forms.ChoiceField(choices=TemperatureData._meta.get_field('month').choices)
    temperature_year = forms.ChoiceField(choices=[(year, str(year)) for year in range(2018, 2027)])
    temperature_average_temperature = forms.FloatField()

    rainfall_month = forms.ChoiceField(choices=RainfallData._meta.get_field('month').choices)
    rainfall_year = forms.ChoiceField(choices=[(year, str(year)) for year in range(2018, 2027)])
    rainfall_rainfall_amount = forms.FloatField()

    population_density_year = forms.ChoiceField(choices=[(year, str(year)) for year in range(2018, 2027)])
    population_density_population_density = forms.FloatField()

    vegetation_health_month = forms.ChoiceField(choices=VegetationHealth._meta.get_field('month').choices)
    vegetation_health_year = forms.ChoiceField(choices=[(year, str(year)) for year in range(2018, 2027)])
    vegetation_health_ndvi_value = forms.FloatField()

    disaster_type_name = forms.ChoiceField(choices=DisasterType.DISASTER_TYPE_CHOICES)
    disaster_history_severity_level = forms.CharField(max_length=20)
    disaster_history_occurrence_date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))
