from django.contrib import admin
from .models import District, TemperatureData, VegetationHealth, RainfallData, PopulationDensity, DisasterHistory, DisasterType

# Register your models here.
admin.site.register(District)
admin.site.register(TemperatureData)
admin.site.register(VegetationHealth)
admin.site.register(RainfallData)
admin.site.register(PopulationDensity)
admin.site.register(DisasterHistory)
admin.site.register(DisasterType)


