from . import views
from django.conf import settings
from django.conf.urls.static import static
from django.urls import path

urlpatterns = [
  path('', views.home, name='home-page' ),
  path('/data/<int:district_id>/', views.landing, name="data-home"),
  path('update/', views.add_all_data, name="update-data"),
  path('/login/', views.login_view , name='login'),
  path('/logout/', views.logoutuser, name='logout'),


  path('disaster-prediction/', views.disaster_prediction, name='disaster_prediction'),
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
