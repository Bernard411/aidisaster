# models.py

from django.db import models
from django.contrib.auth.models import User

class District(models.Model):
    # Define choices for all 28 districts in Malawi
    DISTRICT_CHOICES = [
        ('Balaka', 'Balaka'),
        ('Blantyre', 'Blantyre'),
        ('Chikwawa', 'Chikwawa'),
        ('Chiradzulu', 'Chiradzulu'),
        ('Chitipa', 'Chitipa'),
        ('Dedza', 'Dedza'),
        ('Dowa', 'Dowa'),
        ('Karonga', 'Karonga'),
        ('Kasungu', 'Kasungu'),
        ('Likoma', 'Likoma'),
        ('Lilongwe', 'Lilongwe'),
        ('Machinga', 'Machinga'),
        ('Mangochi', 'Mangochi'),
        ('Mchinji', 'Mchinji'),
        ('Mulanje', 'Mulanje'),
        ('Mwanza', 'Mwanza'),
        ('Mzimba', 'Mzimba'),
        ('Neno', 'Neno'),
        ('Nkhata Bay', 'Nkhata Bay'),
        ('Nkhotakota', 'Nkhotakota'),
        ('Nsanje', 'Nsanje'),
        ('Ntcheu', 'Ntcheu'),
        ('Ntchisi', 'Ntchisi'),
        ('Phalombe', 'Phalombe'),
        ('Rumphi', 'Rumphi'),
        ('Salima', 'Salima'),
        ('Thyolo', 'Thyolo'),
        ('Zomba', 'Zomba'),
    ]

    name = models.CharField(max_length=100, choices=DISTRICT_CHOICES, unique=True)


    def __str__(self):
        return self.name

# Rest of the models remain the same


class TemperatureData(models.Model):
    district = models.ForeignKey(District, on_delete=models.CASCADE)
    month = models.CharField(max_length=20, choices=[
        ('January', 'January'),
        ('February', 'February'),
        ('March', 'March'),
        ('April', 'April'),
        ('May', 'May'),
        ('June', 'June'),
        ('July', 'July'),
        ('August', 'August'),
        ('September', 'September'),
        ('October', 'October'),
        ('November', 'November'),
        ('December', 'December'),
    ])
    year = models.IntegerField(choices=[(year, str(year)) for year in range(2018, 2027)])
    average_temperature = models.FloatField()

class RainfallData(models.Model):
    district = models.ForeignKey(District, on_delete=models.CASCADE)
    month = models.CharField(max_length=20, choices=[
        ('January', 'January'),
        ('February', 'February'),
        ('March', 'March'),
        ('April', 'April'),
        ('May', 'May'),
        ('June', 'June'),
        ('July', 'July'),
        ('August', 'August'),
        ('September', 'September'),
        ('October', 'October'),
        ('November', 'November'),
        ('December', 'December'),
    ])
    year = models.IntegerField(choices=[(year, str(year)) for year in range(2018, 2027)])
    rainfall_amount = models.FloatField()

class PopulationDensity(models.Model):
    district = models.OneToOneField(District, on_delete=models.CASCADE)
    year = models.IntegerField(choices=[(year, str(year)) for year in range(2018, 2027)])
    population_density = models.FloatField()

class VegetationHealth(models.Model):
    district = models.ForeignKey(District, on_delete=models.CASCADE)
    year = models.IntegerField(choices=[(year, str(year)) for year in range(2018, 2027)])
    month = models.CharField(max_length=20, choices=[
        ('January', 'January'),
        ('February', 'February'),
        ('March', 'March'),
        ('April', 'April'),
        ('May', 'May'),
        ('June', 'June'),
        ('July', 'July'),
        ('August', 'August'),
        ('September', 'September'),
        ('October', 'October'),
        ('November', 'November'),
        ('December', 'December'),
    ])
    ndvi_value = models.FloatField()




class DisasterType(models.Model):
    FLOOD = 'Flood'
    DROUGHT = 'Drought'
    EARTHQUAKE = 'Earthquake'
    WILDFIRE = 'Wildfire'
    OTHER = 'Other'

    DISASTER_TYPE_CHOICES = [
        (FLOOD, 'Flood'),
        (DROUGHT, 'Drought'),
        (EARTHQUAKE, 'Earthquake'),
        (WILDFIRE, 'Wildfire'),
        (OTHER, 'Other'),
    ]
    district = models.ForeignKey(District, on_delete=models.CASCADE)
    name = models.CharField(max_length=20, choices=DISASTER_TYPE_CHOICES, unique=True)
    

    def __str__(self):
        return self.name

class DisasterHistory(models.Model):
    district = models.ForeignKey(District, on_delete=models.CASCADE)
    disaster_type = models.ForeignKey(DisasterType, on_delete=models.CASCADE)
    severity_level = models.CharField(max_length=20)
    occurrence_date = models.DateField()

    def __str__(self):
        return f"{self.disaster_type} in {self.district} on {self.occurrence_date}"




