import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split

# Load the rainfall dataset
rainfall_file_path = 'rainfall.csv'
rainfall_data = pd.read_csv(rainfall_file_path)

# Preprocess rainfall data
rainfall_data = rainfall_data[['region', 'Date', 'Value']]

# Drop rows with missing values
rainfall_data = rainfall_data.dropna()

# Convert data to PyTorch tensors
features = rainfall_data[['Value']]
target = rainfall_data['region']

# Use LabelEncoder to convert categorical target variable to numerical values
label_encoder = LabelEncoder()
target_encoded = label_encoder.fit_transform(target)

# Use StandardScaler to normalize the features
scaler = StandardScaler()
features_scaled = scaler.fit_transform(features)

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(features_scaled, target_encoded, test_size=0.2, random_state=42)

# Convert data to PyTorch tensors
X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
y_train_tensor = torch.tensor(y_train, dtype=torch.long)
X_test_tensor = torch.tensor(X_test, dtype=torch.float32)
y_test_tensor = torch.tensor(y_test, dtype=torch.long)

# Create a TensorDataset for training and testing sets
train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
test_dataset = TensorDataset(X_test_tensor, y_test_tensor)

# Create DataLoader for training and testing sets
batch_size = 64
train_dataloader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
test_dataloader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

# Define your neural network architecture for rainfall prediction
class RainfallModel(nn.Module):
    def __init__(self, input_size, output_size):
        super(RainfallModel, self).__init__()
        self.fc1 = nn.Linear(input_size, 64)
        self.relu = nn.ReLU()
        self.fc2 = nn.Linear(64, output_size)

    def forward(self, x):
        x = self.fc1(x)
        x = self.relu(x)
        x = self.fc2(x)
        return x

# Instantiate the rainfall model
input_size_rainfall = 1  # Adjust input_size based on the number of features in your rainfall data
output_size_rainfall = len(label_encoder.classes_)  # Number of classes in your target variable
rainfall_model = RainfallModel(input_size_rainfall, output_size_rainfall)

# Define loss function and optimizer for classification
criterion_rainfall = nn.CrossEntropyLoss()
optimizer_rainfall = optim.Adam(rainfall_model.parameters(), lr=0.001)

# Training loop for rainfall model
num_epochs_rainfall = 10

for epoch in range(num_epochs_rainfall):
    for batch_inputs, batch_targets in train_dataloader:
        # Forward pass
        outputs_rainfall = rainfall_model(batch_inputs)

        # Compute the loss
        loss_rainfall = criterion_rainfall(outputs_rainfall, batch_targets)

        # Backward pass and optimization
        optimizer_rainfall.zero_grad()
        loss_rainfall.backward()
        optimizer_rainfall.step()

    # Print the loss for every epoch
    print(f'Epoch {epoch+1}/{num_epochs_rainfall}, Loss: {loss_rainfall.item()}')

# Save your trained rainfall model
torch.save(rainfall_model.state_dict(), 'rainfall_model.pth')
