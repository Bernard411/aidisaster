import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split

# Load the temperature dataset
temperature_file_path = 'temperature.csv'
temperature_data = pd.read_csv(temperature_file_path)

# Preprocess temperature data
temperature_data = temperature_data[temperature_data['indicator'] == 'Max']
temperature_data = temperature_data[['region', 'Date', 'Value']]

# Drop rows with missing values
temperature_data = temperature_data.dropna()

# Convert data to PyTorch tensors
features_temperature = temperature_data[['Value']]
target_temperature = temperature_data['region']

# Use LabelEncoder to convert categorical target variable to numerical values
label_encoder_temperature = LabelEncoder()
target_encoded_temperature = label_encoder_temperature.fit_transform(target_temperature)

# Use StandardScaler to normalize the features
scaler_temperature = StandardScaler()
features_scaled_temperature = scaler_temperature.fit_transform(features_temperature)

# Split the data into training and testing sets
X_train_temperature, X_test_temperature, y_train_temperature, y_test_temperature = train_test_split(
    features_scaled_temperature, target_encoded_temperature, test_size=0.2, random_state=42
)

# Convert data to PyTorch tensors
X_train_tensor_temperature = torch.tensor(X_train_temperature, dtype=torch.float32)
y_train_tensor_temperature = torch.tensor(y_train_temperature, dtype=torch.long)
X_test_tensor_temperature = torch.tensor(X_test_temperature, dtype=torch.float32)
y_test_tensor_temperature = torch.tensor(y_test_temperature, dtype=torch.long)

# Create a TensorDataset for training and testing sets
train_dataset_temperature = TensorDataset(X_train_tensor_temperature, y_train_tensor_temperature)
test_dataset_temperature = TensorDataset(X_test_tensor_temperature, y_test_tensor_temperature)

# Create DataLoader for training and testing sets
batch_size_temperature = 64
train_dataloader_temperature = DataLoader(train_dataset_temperature, batch_size=batch_size_temperature, shuffle=True)
test_dataloader_temperature = DataLoader(test_dataset_temperature, batch_size=batch_size_temperature, shuffle=False)

# Define your neural network architecture for temperature prediction
class TemperatureModel(nn.Module):
    def __init__(self, input_size, output_size):
        super(TemperatureModel, self).__init__()
        self.fc1 = nn.Linear(input_size, 64)
        self.relu = nn.ReLU()
        self.fc2 = nn.Linear(64, output_size)

    def forward(self, x):
        x = self.fc1(x)
        x = self.relu(x)
        x = self.fc2(x)
        return x

# Instantiate the temperature model
input_size_temperature = 1  # Adjust input_size based on the number of features in your temperature data
output_size_temperature = len(label_encoder_temperature.classes_)  # Number of classes in your target variable
temperature_model = TemperatureModel(input_size_temperature, output_size_temperature)

# Define loss function and optimizer for classification
criterion_temperature = nn.CrossEntropyLoss()
optimizer_temperature = optim.Adam(temperature_model.parameters(), lr=0.001)

# Training loop for temperature model
num_epochs_temperature = 10

for epoch in range(num_epochs_temperature):
    for batch_inputs_temperature, batch_targets_temperature in train_dataloader_temperature:
        # Forward pass
        outputs_temperature = temperature_model(batch_inputs_temperature)

        # Compute the loss
        loss_temperature = criterion_temperature(outputs_temperature, batch_targets_temperature)

        # Backward pass and optimization
        optimizer_temperature.zero_grad()
        loss_temperature.backward()
        optimizer_temperature.step()

    # Print the loss for every epoch
    print(f'Epoch {epoch+1}/{num_epochs_temperature}, Loss: {loss_temperature.item()}')

# Save your trained temperature model
torch.save(temperature_model.state_dict(), 'temperature_model.pth')
